document.addEventListener("DOMContentLoaded", () => {
    // Sample restaurant data
    const restaurants = [{
            name: "Taj Mahal Restaurant",
            image: "https://via.placeholder.com/200x120.png?text=Taj+Mahal+Restaurant",
            rating: 4.5,
            category: "Indian"
        },
        {
            name: "Pizza Hut",
            image: "https://via.placeholder.com/200x120.png?text=Pizza+Hut",
            rating: 4.0,
            category: "Italian"
        },
        {
            name: "Dragon Wok",
            image: "https://via.placeholder.com/200x120.png?text=Dragon+Wok",
            rating: 4.2,
            category: "Chinese"
        },
        {
            name: "McDonald's",
            image: "https://via.placeholder.com/200x120.png?text=McDonald's",
            rating: 3.8,
            category: "Fast Food"
        },
        // More restaurants...
    ];

    // Render Restaurants
    const restaurantList = document.querySelector(".restaurant-list");
    restaurants.forEach(restaurant => {
        const restaurantCard = document.createElement("div");
        restaurantCard.classList.add("restaurant-card");
        restaurantCard.innerHTML = `
      <img src="${restaurant.image}" alt="${restaurant.name}">
      <div class="info">
        <div class="name">${restaurant.name}</div>
        <div class="rating">Rating: ${restaurant.rating} ★</div>
      </div>
    `;
        restaurantList.appendChild(restaurantCard);
    });

    // Search Functionality
    const searchBar = document.getElementById("search-bar");
    searchBar.addEventListener("input", (e) => {
        const query = e.target.value.toLowerCase();
        const filteredRestaurants = restaurants.filter(restaurant =>
            restaurant.name.toLowerCase().includes(query) ||
            restaurant.category.toLowerCase().includes(query)
        );
        restaurantList.innerHTML = "";
        filteredRestaurants.forEach(restaurant => {
            const restaurantCard = document.createElement("div");
            restaurantCard.classList.add("restaurant-card");
            restaurantCard.innerHTML = `
        <img src="${restaurant.image}" alt="${restaurant.name}">
        <div class="info">
          <div class="name">${restaurant.name}</div>
          <div class="rating">Rating: ${restaurant.rating} ★</div>
        </div>
      `;
            restaurantList.appendChild(restaurantCard);
        });
    });
});